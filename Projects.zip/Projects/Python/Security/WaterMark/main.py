# watermark
import cv2
from stegano import *


image_path = "C:/Users/User/Desktop/Cours/Programation/Cours/Computer_Science/Steganographie/pennywise.jpg"
image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)


text = "Nique ta race"

steg_image = steganography_image(image,text)

cv2.imshow("steg_image",steg_image)
cv2.waitKey(0)

print(get_text_from_steganography_image(steg_image))
