alphabet = ["z","y","x","w","v","u","t","s","r","q","p","o","n","m","l","k","j","i","h","g","f","e","d","c","b","a","z","y","x","w","v","u","t","s","r","q","p","o","n","m","l","k","j","i","h","g","f","e","d","c","b"]
mot = input("donner le message a decoder : ")
n = int(input("Incrémentation : "))

mot_liste = list(mot)

crypt_list = []
# in=0
# print(mot_liste)
for i in range(len(mot_liste)):


    if mot_liste[i] != ' ':

        ind = alphabet.index(mot_liste[i])
        yo = alphabet[ind + n]
        crypt_list.append(yo)

    else :
        crypt_list.append(' ')

print(''.join(crypt_list))
